#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

// Class defining the Student structure
class Student {
public:
    string id;
    string name;
    string department;
    int level;
    float gpa;

    // Helper method to neatly display student details
    void display() const {
        cout << "ID: " << id << " | Name: " << name 
             << " | Department: " << department 
             << " | Level: " << level << " | GPA: " << gpa << endl;
    }
};

// Function prototypes
void addStudent(vector<Student>& students);
void viewAllStudents(const vector<Student>& students);
void searchStudent(const vector<Student>& students);
void updateStudent(vector<Student>& students);
void deleteStudent(vector<Student>& students);
void calculateGPA(vector<Student>& students);
void saveRecords(const vector<Student>& students);
void loadRecords(vector<Student>& students);

int main() {
    vector<Student> students;
    int choice;

    // Load existing records right when the program starts
    loadRecords(students);

    do {
        cout << "\n========== STUDENT MANAGEMENT SYSTEM ==========\n";
        cout << "1. Add Student\n";
        cout << "2. View All Students\n";
        cout << "3. Search Student\n";
        cout << "4. Update Student\n";
        cout << "5. Delete Student\n";
        cout << "6. Calculate GPA\n";
        cout << "7. Save Records\n";
        cout << "8. Load Records\n";
        cout << "9. Exit\n";
        cout << "===============================================\n";
        cout << "Enter your choice (1-9): ";
        cin >> choice;

        switch (choice) {
            case 1:
                addStudent(students);
                break;
            case 2:
                viewAllStudents(students);
                break;
            case 3:
                searchStudent(students);
                break;
            case 4:
                updateStudent(students);
                break;
            case 5:
                deleteStudent(students);
                break;
            case 6:
                calculateGPA(students);
                break;
            case 7:
                saveRecords(students);
                break;
            case 8:
                loadRecords(students);
                break;
            case 9:
                // Auto-saves student records to the file before exiting
                saveRecords(students);
                cout << "Exiting program. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice! Please choose between 1 and 9.\n";
        }
    } while (choice != 9);

    return 0;
}

// 1. Add a new student record
void addStudent(vector<Student>& students) {
    Student s;
    cout << "\n--- Add New Student ---\n";
    cout << "Enter Student ID: ";
    cin >> s.id;
    cin.ignore(); // Clears input buffer before using getline

    cout << "Enter Full Name: ";
    getline(cin, s.name);

    cout << "Enter Department: ";
    getline(cin, s.department);

    cout << "Enter Level: ";
    cin >> s.level;

    s.gpa = 0.0; // GPA starts at 0.0 until calculated

    students.push_back(s);
    cout << "Student registration successful!\n";
}

// 2. View all students in the database
void viewAllStudents(const vector<Student>& students) {
    if (students.empty()) {
        cout << "\nNo student records found.\n";
        return;
    }
    cout << "\n--- Registered Students ---\n";
    for (const auto& s : students) {
        s.display();
    }
}

// 3. Search for a student by ID or Name
void searchStudent(const vector<Student>& students) {
    if (students.empty()) {
        cout << "\nNo student records available to search.\n";
        return;
    }

    int searchChoice;
    cout << "\nSearch by:\n1. Student ID\n2. Name\nEnter Choice: ";
    cin >> searchChoice;
    cin.ignore();

    bool found = false;

    if (searchChoice == 1) {
        string searchId;
        cout << "Enter Student ID to search: ";
        cin >> searchId;
        for (const auto& s : students) {
            if (s.id == searchId) {
                cout << "\nStudent Found:\n";
                s.display();
                found = true;
                break;
            }
        }
    } else if (searchChoice == 2) {
        string searchName;
        cout << "Enter Student Name to search: ";
        getline(cin, searchName);
        for (const auto& s : students) {
            if (s.name == searchName) {
                cout << "\nStudent Found:\n";
                s.display();
                found = true;
            }
        }
    } else {
        cout << "Invalid Option.\n";
        return;
    }

    if (!found) {
        cout << "No matching student record found.\n";
    }
}

// 4. Update existing student information
void updateStudent(vector<Student>& students) {
    string searchId;
    cout << "\nEnter Student ID to update details: ";
    cin >> searchId;

    for (auto& s : students) {
        if (s.id == searchId) {
            cin.ignore();
            cout << "Student profile found for: " << s.name << endl;
            cout << "Enter New Department: ";
            getline(cin, s.department);
            cout << "Enter New Level: ";
            cin >> s.level;
            cout << "Profile updated successfully!\n";
            return;
        }
    }
    cout << "Student with ID " << searchId << " not found.\n";
}

// 5. Delete a student record
void deleteStudent(vector<Student>& students) {
    string searchId;
    cout << "\nEnter Student ID to delete: ";
    cin >> searchId;

    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->id == searchId) {
            students.erase(it);
            cout << "Student profile deleted successfully.\n";
            return;
        }
    }
    cout << "Student with ID " << searchId << " not found.\n";
}

// 6. Enter course data and dynamically calculate a student's GPA
void calculateGPA(vector<Student>& students) {
    string searchId;
    cout << "\nEnter Student ID to calculate GPA: ";
    cin >> searchId;

    for (auto& s : students) {
        if (s.id == searchId) {
            int numCourses;
            cout << "Enter total number of courses: ";
            cin >> numCourses;

            float totalPoints = 0.0;
            float totalCredits = 0.0;

            for (int i = 0; i < numCourses; i++) {
                float gradePoint;
                float credits;

                cout << "\nCourse " << (i + 1) << " - Grade Point (e.g., 4.0 for A, 3.0 for B): ";
                cin >> gradePoint;
                cout << "Course " << (i + 1) << " - Credit Hours: ";
                cin >> credits;

                totalPoints += (gradePoint * credits);
                totalCredits += credits;
            }

            if (totalCredits > 0) {
                s.gpa = totalPoints / totalCredits;
                cout << "\nCalculated GPA: " << s.gpa << endl;
                cout << "GPA updated in student record!\n";
            } else {
                cout << "Credit hours must be greater than zero.\n";
            }
            return;
        }
    }
    cout << "Student with ID " << searchId << " not found.\n";
}

// 7. Save records into 'students.txt'
void saveRecords(const vector<Student>& students) {
    ofstream fout("students.txt");
    if (!fout) {
        cout << "Error opening data file for saving.\n";
        return;
    }

    for (const auto& s : students) {
        fout << s.id << "\n" 
             << s.name << "\n" 
             << s.department << "\n" 
             << s.level << "\n" 
             << s.gpa << "\n";
    }
    fout.close();
    cout << "Data saved successfully to students.txt!\n";
}

// 8. Load records from 'students.txt'
void loadRecords(vector<Student>& students) {
    ifstream fin("students.txt");
    if (!fin) {
        cout << "No previous records found. Starting a fresh session.\n";
        return;
    }

    students.clear(); // Clear existing vectors to prevent duplication
    Student s;

    // Read the space-separated and line-separated elements back into memory
    while (fin >> s.id) {
        fin.ignore(); // Ignores newline after ID
        getline(fin, s.name);
        getline(fin, s.department);
        fin >> s.level;
        fin >> s.gpa;
        students.push_back(s);
    }
    fin.close();
    cout << "Previous records loaded successfully from students.txt!\n";
}